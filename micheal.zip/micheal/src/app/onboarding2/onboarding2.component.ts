import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboarding2',
  templateUrl: './onboarding2.component.html',
  styleUrls: ['./onboarding2.component.css']
})
export class Onboarding2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
