import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboarding3',
  templateUrl: './onboarding3.component.html',
  styleUrls: ['./onboarding3.component.css']
})
export class Onboarding3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
