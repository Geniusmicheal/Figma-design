import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
// import { HttpModule } from '@angular/Http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OnboardingComponent } from './onboarding/onboarding.component';
import { Onboarding2Component } from './onboarding2/onboarding2.component';
import { Onboarding3Component } from './onboarding3/onboarding3.component';




@NgModule({
  declarations: [
    AppComponent,
    OnboardingComponent,
    Onboarding2Component,
    Onboarding3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    // HttpModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
